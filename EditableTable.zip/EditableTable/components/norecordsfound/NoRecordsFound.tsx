import React from 'react';

const NoRecordsFound = ({ editableTableHead }: { editableTableHead: any }) => {
  return (
    <tr>
      <td
        className="border-b text-center border-gray-300"
        colSpan={editableTableHead?.length}
      >
        <div className="flex flex-col items-center justify-center pt-1">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="w-10 h-10 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M11.016 6.43a5.002 5.002 0 10-5.036 5.036M16.35 16.35A5.978 5.978 0 0112 18a5.978 5.978 0 01-4.35-1.65m10.7-4.8a5.978 5.978 0 01-2.051 3.7A6.017 6.017 0 0112 18a5.978 5.978 0 01-4.35-1.65M12 3v2M12 19v2M3 12h2M19 12h2M6.34 6.34l1.42 1.42M16.24 16.24l1.42 1.42M6.34 17.66l1.42-1.42M16.24 7.76l1.42-1.42"
            />
          </svg>
          <h2 className="text-sm font-semibold text-gray-700 mb-2">
            No Records Found
          </h2>
        </div>
      </td>
    </tr>
  );
};

export default NoRecordsFound;
