import { CircularProgress } from '@mui/material';

export default function Loader({
  editableTableHead,
}: {
  editableTableHead: any;
}) {
  console.log(editableTableHead?.length);
  return (
    <tr>
      <td className="p-4 border-b border-gray-300" colSpan={8}>
        <div className='font-semibold flex gap-2 items-center justify-center'>
          <CircularProgress size={20} />
          Loading...
        </div>
      </td>
    </tr>
  );
}
