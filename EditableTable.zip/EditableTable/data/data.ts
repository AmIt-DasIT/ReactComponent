import { HeaderConfig } from '../types/type';

export const editableTableHead: HeaderConfig[] = [
  {
    field: 'id',
    headerText: 'ID',
    show: false,
    isDisabled: true,
  },
  {
    field: 'checkbox',
    headerText: '',
    show: true,
    width: '50px',
    field_type: 'checkbox',
  },
  {
    field: 'bankTransactionDate',
    headerText: 'Bank Transaction Date',
    show: true,
    width: '190px',
    field_type: 'date',
  },
  {
    field: 'particulars',
    headerText: 'Particulars',
    show: true,
    width: '400px',
    field_type: 'textarea',
  },
  {
    field: 'chequeNo',
    headerText: 'Cheque No',
    show: true,
    width: '200px',
  },
  {
    field: 'dbAmt',
    headerText: 'Debit Amount',
    show: true,
    width: '200px',
  },
  {
    field: 'crAmt',
    headerText: 'Credit Amount',
    show: true,
    width: '180px',
  },
  {
    field: 'balance',
    headerText: 'Balance',
    show: true,
  },
];
