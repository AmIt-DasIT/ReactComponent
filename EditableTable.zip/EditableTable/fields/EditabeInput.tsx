import React from 'react';

type EditabeInputProps = React.DetailedHTMLProps<
  React.InputHTMLAttributes<HTMLInputElement>,
  HTMLInputElement
> & {
  label?: string;
  viewonly?: boolean;
};

export default function EditabeInput({
  id,
  label,
  viewonly,
  value,
  style,
  className = '',
  ...rest
}: EditabeInputProps) {
  return (
    <div className="text-wrap" style={style}>
      <div className="block tracking-wide text-xs">{label}</div>
      {!viewonly ? (
        <input
          className={`appearance-none block rounded-md text-gray-700 border border-gray-200 py-1.5 px-3 leading-tight focus:outline-none focus:bg-white focus:border-blue-700 disabled:bg-gray-100 min-w-[150px] ${className}`}
          id={id}
          value={value}
          style={style}
          {...rest}
        />
      ) : (
        value
      )}
    </div>
  );
}
