import {
  DatePickerComponent,
  DatePickerModel,
} from '@syncfusion/ej2-react-calendars';
import { DefaultHtmlAttributes } from '@syncfusion/ej2-react-base';
import { registerLicense } from '@syncfusion/ej2-base';

registerLicense(
  'Ngo9BigBOggjHTQxAR8/V1NGaF1cWGhIfEx1RHxQdld5ZFRHallYTnNWUj0eQnxTdEZjXnxecHdXTmReUUV3Vg=='
);

type EditableDatePickerProps = DatePickerModel &
  DefaultHtmlAttributes & {
    label?: string;
    className?: string;
    error?: string | boolean;
  };
export default function EditableDatePicker({
  label,
  error,
  ...rest
}: EditableDatePickerProps) {
  return (
    <div className="h-8 relative top-0">
      {label && (
        <div
          className={`block tracking-wide text-xs ${error && 'text-[#ff0000]'}`}
        >
          {label}
        </div>
      )}
      <DatePickerComponent
        {...rest}
        style={{
          ...rest.style,
          color: error ? '#ff0000' : '#222222',
        }}
      />
      {error && <div className="text-[#ff0000] text-xs">{error}</div>}
    </div>
  );
}
