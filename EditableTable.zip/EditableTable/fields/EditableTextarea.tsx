import { Box, Modal } from '@mui/material';
import React from 'react';
import EditabeInput from './EditabeInput';

type EditableTextareaProps = React.DetailedHTMLProps<
  React.TextareaHTMLAttributes<HTMLTextAreaElement>,
  HTMLTextAreaElement
> & {
  label?: string;
  viewonly?: boolean;
};

export default function EditableTextarea({
  id,
  label,
  value,
  className = 'w-full',
  viewonly,
  ...rest
}: EditableTextareaProps) {
  const [open, setOpenModal] = React.useState(false);
  const handleOpen = () => setOpenModal(true);
  const handleClose = () => setOpenModal(false);
  return (
    <>
      {viewonly ? (
        value
      ) : (
        <>
          <EditabeInput
            type="text"
            label={label}
            value={value}
            onClick={handleOpen}
            className="w-full"
          />
          <Modal open={open} onClose={handleClose}>
            <Box
              sx={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '50%',
                bgcolor: 'background.paper',
                boxShadow: 24,
                p: 3,
                borderRadius: '10px',
              }}
            >
              <label
                className="block tracking-wide text-gray-700 text-sm font-bold"
                htmlFor={id}
              >
                {label}
              </label>
              <textarea
                className={`appearance-none block rounded-md text-gray-700 border border-gray-200 py-2 px-3 leading-tight focus:outline-none focus:bg-white focus:border-blue-700 disabled:bg-gray-100 ${className}`}
                id={id}
                value={value}
                {...rest}
              />
            </Box>
          </Modal>
        </>
      )}
    </>
  );
}
