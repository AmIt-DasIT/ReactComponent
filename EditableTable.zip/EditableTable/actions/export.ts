import saveAs from 'file-saver';
import { TransformedTransaction } from '../types/type';
import * as XLSX from 'xlsx';

export const exportToExcel = (
  data: TransformedTransaction[],
  fileName: string
) => {
  // Create a new workbook and add a worksheet
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.json_to_sheet(data);

  // Add the worksheet to the workbook
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

  // Convert the workbook to a binary string and save it
  const excelBuffer = XLSX.write(workbook, {
    bookType: 'xlsx',
    type: 'array',
  });
  const file = new Blob([excelBuffer], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  saveAs(file, `${fileName}.xlsx`);
};
