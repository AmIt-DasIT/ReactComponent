export const handlePrint = () => {
  const printWindow = window.open('', '', 'height=600,width=800');
  printWindow?.document.write('<html><head><title>Print</title></head><body>');
  printWindow?.document.write(document.querySelector('table')?.outerHTML || '');
  printWindow?.document.write('</body></html>');
  printWindow?.document.close();
  printWindow?.focus();
  printWindow?.print();
};
