import moment from 'moment';
import {
  ConvertedDataForUpdate,
  DataItem,
  TransformedTransaction,
} from '../types/type';

export const transformData = (data: DataItem[]): TransformedTransaction[] => {
  return data
    .flatMap((item) =>
      item.transactions.map((transaction) => ({
        bankTransactionDate: transaction.bankTransactionDate,
        particulars: transaction.particulars,
        chequeNo: transaction.chequeNo,
        dbAmt: transaction.dbAmt,
        crAmt: transaction.crAmt,
        balance: transaction.balance,
        id: transaction.id,
      }))
    )
    ?.sort(
      (a: any, b: any) =>
        (new Date(a.bankTransactionDate) as any) - (new Date(b.bankTransactionDate) as any)
    );
};

// export const convertData = (
//   sourceData: TransformedTransaction[]
// ): ConvertedDataForUpdate => {
//   return {
//     id: sourceData[0]?.id
//     accountId: sourceData[0]?.,
//     fromDate: '2023-11-01', // Placeholder fromDate
//     toDate: '2023-12-31', // Placeholder toDate
//     docId: '/path/to/file', // Placeholder docId
//     data: sourceData.map((transaction) => ({
//       bankTransactionDate: transaction.bankTransactionDate,
//       particulars: transaction.particulars,
//       chequeNo: transaction.chequeNo,
//       dbAmt: parseFloat(transaction.dbAmt.replace(/,/g, '')),
//       crAmt: transaction.crAmt
//         ? parseFloat((transaction.crAmt as string).replace(/,/g, ''))
//         : 0,
//       balance: parseFloat(
//         transaction.balance.replace(/,/g, '').replace('Cr', '')
//       ),
//     })),
//   };
// };
