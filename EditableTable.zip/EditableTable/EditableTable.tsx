import {
  Checkbox,
  CircularProgress,
  TableContainer,
  TablePagination,
} from '@mui/material';
import { nanoid } from '@reduxjs/toolkit';
import { capitalizeFirstLetter } from '@syncfusion/ej2-react-grids';
import React, { useState, useMemo, ReactElement } from 'react';
import AddRowModal from './modals/AddRowModal';
import DeleteRowModal from './modals/DeleteRowModal';
import EditabeInput from './fields/EditabeInput';
import Sort from './actions/Sort';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import {
  EditableTableType,
  HeaderConfig,
  sortConfigType,
  TransformedTransaction,
} from './types/type';
import EditableTextarea from './fields/EditableTextarea';
import EditableDatePicker from './fields/EditableDatePicker';
import NoRecordsFound from './components/norecordsfound/NoRecordsFound';
import { exportToExcel } from './actions/export';
import Loader from './components/loader/Loader';
import BulkDeleteRowModal from './modals/BulkDeleteRowModal';
import { handlePrint } from './actions/print';

/**
 * EditableTable component
 * @description A table component with add, edit and delete functionality
 * @param {Object} props component props
 * @returns {ReactElement} EditableTable component
 */

const EditableTable = ({
  data = [],
  editableTableHead,
  setData,
  viewonly = false,
  loading = false,
  allowExcelExport = false,
  allowPrint = false,
}: EditableTableType): ReactElement => {
  // ------------------------------------------------------------------------------------------------------------------
  // Pagination Handler Functions -------------------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------
  const [page, setPage] = useState(0); // current page
  const [rowsPerPage, setRowsPerPage] = useState(14); // rows per page
  const handleChangePage = (
    // page change handler
    event: React.MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    // rows per page change handler
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Add Row Handler Functions ----------------------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const [openModal, setOpenModal] = useState(false); // add row modal open state
  const [newRow, setNewRow] = useState<TransformedTransaction>({
    bankTransactionDate: '',
    particulars: '',
    chequeNo: '',
    dbAmt: '',
    crAmt: '',
    balance: '',
    id: nanoid(),
  });
  const handleAddClick = () => {
    // add row click handler
    setData([newRow, ...data]);
    setNewRow({
      bankTransactionDate: '',
      particulars: '',
      chequeNo: '',
      dbAmt: '',
      crAmt: '',
      balance: '',
      id: nanoid(),
    });
    setOpenModal(false);
  };

  const handleModalOpen = () => setOpenModal(true); // add row modal open handler
  const handleModalClose = () => setOpenModal(false); // add row modal close handler

  const handleInputChange = (name: any, value: any) => {
    console.log(name, value);
    setNewRow((prev) => ({ ...prev, [name]: value }));
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Delete Row Handler Functions -------------------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false); // delete row modal open state
  const handleDeleteModalClose = () => setIsDeleteModalOpen(!isDeleteModalOpen); // delete row modal close handler

  const [deleteId, setDeleteId] = useState(''); // row id to be deleted
  const handleDeleteClick = (id: string) => {
    // delete row click handler
    setData(data.filter((row) => row.id !== id));
    setDeleteId('');
    setIsDeleteModalOpen(false);
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Edit Row Handler Functions ---------------------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const handleRowChange = (
    // row change handler
    id: string,
    name: string,
    value: string | number
  ) => {
    setData(
      data.map((row) => (row.id === id ? { ...row, [name]: value } : row))
    );
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Search Handler Functions ------------------------------------------------------------>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const [searchTerm, setSearchTerm] = useState(''); // search term
  const [sortConfig, setSortConfig] = useState<sortConfigType>({
    // sort config
    key: 'id',
    direction: 'default',
  });

  const filteredData = useMemo(() => {
    if (!searchTerm) return data;

    // Normalize the search term
    const normalizedSearchTerm = searchTerm.toLowerCase();

    // Filter data based on the search term
    return data.filter((row) =>
      Object.values(row).some(
        (value) =>
          typeof value === 'string' &&
          value.toLowerCase().includes(normalizedSearchTerm)
      )
    );
  }, [data, searchTerm]);

  // ------------------------------------------------------------------------------------------------------------------
  // Sort Handler Functions ------------------------------------------------------------>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const sortedData = React.useMemo(() => {
    // sorted data
    // if the sort direction is default, return the filtered data as it is
    // otherwise, sort the filtered data based on the sort config
    const sortedArray =
      sortConfig.direction === 'default'
        ? filteredData
        : [...filteredData].sort((a, b) => {
            if (a[sortConfig?.key] < b[sortConfig?.key])
              return sortConfig.direction === 'asc' ? -1 : 1;
            if (a[sortConfig?.key] > b[sortConfig?.key])
              return sortConfig.direction === 'asc' ? 1 : -1;
            return 0;
          });
    return sortedArray;
  }, [filteredData, sortConfig]);

  const handleSort = (key: keyof TransformedTransaction) => {
    // Determine the new sort direction based on the current sort configuration.
    const direction =
      sortConfig.key === key && sortConfig.direction === 'asc' // If the same column is being sorted and it's currently sorted in ascending order
        ? 'desc' // Change the sort direction to descending.
        : sortConfig.direction === 'desc' // If the same column is being sorted and it's currently sorted in descending order
          ? 'default' // Change the sort direction to default (no sorting).
          : 'asc'; // If a different column is being sorted or the current column is not being sorted, sort in ascending order.

    // Update the sort configuration with the new key and direction.
    setSortConfig({ key, direction });
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Select Row Handler Functions ------------------------------------------------------>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState(false);
  const handleBulkDeleteModalClose = () => setIsBulkDeleteModalOpen(false);

  const handleRowSelect = (id: string) => {
    setSelectedRows((prev) => {
      const newSelectedRows = new Set(prev);
      if (newSelectedRows.has(id)) {
        newSelectedRows.delete(id);
      } else {
        newSelectedRows.add(id);
      }
      return newSelectedRows;
    });
  };

  const handleBulkDelete = () => {
    setData(data.filter((row) => !selectedRows.has(row.id)));
    setSelectedRows(new Set());
    setIsBulkDeleteModalOpen(false);
  };

  // ------------------------------------------------------------------------------------------------------------------
  // Render Field Function Based On Field Type -------------------------------------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>
  // ------------------------------------------------------------------------------------------------------------------

  const renderField = (
    columndata: HeaderConfig,
    row: TransformedTransaction,
    handleRowChange: (id: string, name: string, value: string | number) => void,
    id: string
  ): React.ReactNode => {
    // Render a date picker if the field type is "date"
    if (columndata.field_type === 'date') {
      const date = row[columndata.field as keyof TransformedTransaction];
      const dateObj = date ? new Date(date) : undefined;
      return (
        <div style={{ width: columndata.width || '' }}>
          {viewonly ? (
            date
          ) : (
            <EditableDatePicker
              id="datepicker"
              placeholder="Enter date"
              value={dateObj}
              onChange={(selectedDate: any) => {
                console.log(selectedDate);
                handleRowChange(
                  id,
                  columndata.field,
                  new Date(selectedDate?.value).toISOString().split('T')[0]
                );
              }}
              width={columndata.width || ''}
              className="!h-8"
            />
          )}
        </div>
      );
    }

    // Render a text area if the field type is "textarea"
    if (columndata.field_type === 'textarea') {
      return (
        <EditableTextarea
          value={row[columndata.field as keyof TransformedTransaction] || ''}
          onChange={(e) =>
            handleRowChange(id, columndata.field, e.target.value)
          }
          viewonly={viewonly}
          className="min-w-full !h-full"
          rows={20}
        />
      );
    }

    // Render a check box if the field type is "checkbox"
    if (columndata.field_type === 'checkbox') {
      return (
        <>
          {!viewonly && columndata.field === 'checkbox' && (
            <Checkbox
              size="small"
              checked={selectedRows.has(row.id)}
              onChange={() => handleRowSelect(row.id)}
            />
          )}
        </>
      );
    }

    // Render an input box for all other field types
    return (
      <EditabeInput
        value={row[columndata.field as keyof TransformedTransaction] || ''}
        onChange={(e) => handleRowChange(id, columndata.field, e.target.value)}
        style={{
          width: columndata.width || '',
        }}
        viewonly={viewonly}
        className="w-full"
      />
    );
  };

  return (
    <div className="border rounded-xl bg-white overflow-hidden tracking-wide text-sm">
      <div className="flex items-center gap-2 justify-between px-2 pt-4">
        <EditabeInput
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
          placeholder="Search..."
        />
        <div className="flex gap-2">
          {!viewonly && (
            <button
              onClick={handleModalOpen}
              className="bg-blue-500 text-white py-1.5 px-2 rounded shadow-md hover:bg-blue-600 transition flex justify-center items-center"
            >
              <AddIcon className={'mr-0.5'} />
              Add Row
            </button>
          )}
          {allowExcelExport && (
            <button
              onClick={() => exportToExcel(sortedData, 'View Bank Statements')}
              className="bg-green-500 text-white py-1.5 px-2 rounded shadow-md hover:bg-green-600 transition flex justify-center items-center"
            >
              Export to Excel
            </button>
          )}
          {selectedRows.size > 0 && (
            <button
              onClick={() => setIsBulkDeleteModalOpen(true)}
              className="bg-red-500 text-white py-1.5 active:scale-90 px-3 rounded shadow-md hover:bg-red-600 transition flex justify-center items-center"
            >
              Delete Selected
            </button>
          )}
          {allowPrint && (
            <button
              onClick={handlePrint}
              className="bg-indigo-500 text-white py-1.5 px-4 rounded shadow-md hover:bg-indigo-600 transition"
            >
              Print
            </button>
          )}
        </div>
      </div>

      <TableContainer className="mt-2 overflow-x-visible">
        <table className=" bg-white table-auto min-w-full border-collapse text-gray-800">
          <thead>
            <tr className="bg-[#f4f2ff] w-full text-gray-900">
              {editableTableHead
                ?.filter((columndata) => columndata.show)
                .map((column) => (
                  <>
                    {!viewonly && column?.field_type === 'checkbox' ? (
                      <th className="pl-1 border-b border-t border-gray-300 w-8">
                        <Checkbox
                          size="small"
                          checked={
                            filteredData.length === selectedRows.size &&
                            filteredData.length > 0
                          }
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedRows(
                                new Set(filteredData.map((row) => row.id))
                              );
                            } else {
                              setSelectedRows(new Set());
                            }
                          }}
                        />
                      </th>
                    ) : (
                      <th
                        key={column.field}
                        className="px-1 py-3 text-left cursor-pointer pl-2 border-b border-t border-gray-300"
                        onClick={() =>
                          handleSort(
                            column.field as keyof TransformedTransaction
                          )
                        }
                      >
                        <span className="flex items-center text-sm font-semibold">
                          {capitalizeFirstLetter(column.headerText)}
                          <Sort
                            name={column.field as keyof TransformedTransaction}
                            sortConfig={sortConfig}
                          />
                        </span>
                      </th>
                    )}
                  </>
                ))}
              {!viewonly && (
                <th className="py-3 px-4  text-sm font-semibold border-b border-t border-gray-300">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <Loader editableTableHead={editableTableHead} />
            ) : data?.length === 0 ? (
              <NoRecordsFound editableTableHead={editableTableHead} />
            ) : (
              sortedData
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row) => (
                  <tr key={row.id} className="hover:bg-gray-50">
                    {editableTableHead
                      ?.filter((columndata) => columndata.show)
                      ?.map((columndata, index) => (
                        <td
                          className="py-2 px-1 pl-2 border-b border-gray-300"
                          key={index}
                        >
                          {renderField(
                            columndata,
                            row,
                            handleRowChange,
                            row.id
                          )}
                        </td>
                      ))}
                    {!viewonly && (
                      <td className="py-2 px-1 text-center border-b border-gray-300">
                        <DeleteIcon
                          onClick={() => {
                            setIsDeleteModalOpen(true);
                            setDeleteId(row.id);
                          }}
                          className="text-red-500 w-fit active:text-red-600 cursor-pointer transition"
                        />
                      </td>
                    )}
                  </tr>
                ))
            )}
          </tbody>
        </table>
      </TableContainer>
      <TablePagination
        rowsPerPageOptions={[5, 10, 14, 20, 25]}
        component="div"
        count={filteredData.length}
        rowsPerPage={rowsPerPage}
        page={page}
        onPageChange={handleChangePage}
        onRowsPerPageChange={handleChangeRowsPerPage}
        className="bg-[#f4f2ff]"
      />
      <DeleteRowModal
        id={deleteId}
        handleDeleteClick={handleDeleteClick}
        open={isDeleteModalOpen}
        handleClose={handleDeleteModalClose}
      />
      <BulkDeleteRowModal
        handleBulkDelete={handleBulkDelete}
        open={isBulkDeleteModalOpen}
        handleClose={handleBulkDeleteModalClose}
      />
      <AddRowModal
        newRow={newRow}
        handleInputChange={handleInputChange}
        openModal={openModal}
        handleModalClose={handleModalClose}
        handleAddClick={handleAddClick}
        editableTableHead={editableTableHead}
      />
    </div>
  );
};

export default EditableTable;
