import { Modal, Box, Typography } from '@mui/material';

const BulkDeleteRowModal = ({
  handleBulkDelete,
  open,
  handleClose,
}: {
  handleBulkDelete: () => void;
  open: boolean;
  handleClose: any;
}) => {
  return (
    <Modal open={open} onClose={handleClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 400,
          bgcolor: 'background.paper',
          boxShadow: 14,
          p: 4,
          borderRadius: '10px',
        }}
      >
        <Typography
          id="modal-modal-title"
          variant="h6"
          component="h2"
          fontWeight={600}
        >
          Delete Row
        </Typography>
        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
          Are you sure, you want to delete this row?
        </Typography>
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <button
            className="bg-red-500 text-white py-2 px-4 rounded"
            onClick={() => handleBulkDelete()}
          >
            Delete
          </button>
          <button
            onClick={handleClose}
            className="bg-gray-500 text-white py-2 px-4 rounded ml-2"
          >
            Cancel
          </button>
        </Box>
      </Box>
    </Modal>
  );
};

export default BulkDeleteRowModal;
