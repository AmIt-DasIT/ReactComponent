import { Modal, Box } from '@mui/material';
import EditabeInput from '../fields/EditabeInput';
import EditableTextarea from '../fields/EditableTextarea';
import { AddRowType, HeaderConfig } from '../types/type';
import EditableDatePicker from '../fields/EditableDatePicker';
import React from 'react';

interface AddRowModalProps {
  openModal: boolean;
  newRow: AddRowType;
  handleInputChange: (name: any, value: any) => void;
  handleAddClick: () => void;
  handleModalClose: () => void;
  editableTableHead: HeaderConfig[];
}

const AddRowModal: React.FC<AddRowModalProps> = ({
  openModal,
  newRow,
  handleInputChange,
  handleAddClick,
  handleModalClose,
  editableTableHead,
}) => {
  console.log(newRow);
  return (
    <Modal open={openModal} onClose={handleModalClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '50%',
          bgcolor: 'background.paper',
          boxShadow: 24,
          p: 3,
          borderRadius: '10px',
        }}
      >
        <p className="text-xl font-semibold">Add New Row</p>
        <div className="border rounded-xl p-4 grid grid-cols-3 gap-2">
          {editableTableHead
            .filter((data) => data.show)
            .map((data) => {
              const fieldType = data.field_type;
              console.log(data?.field);
              return (
                <React.Fragment key={data.field}>
                  {fieldType === 'date' ? (
                    <EditableDatePicker
                      name={data.field as keyof AddRowType}
                      label="Date"
                      value={new Date(newRow[data.field as keyof AddRowType])}
                      onChange={(selectedDate: any) =>
                        handleInputChange(
                          data.field,
                          new Date(selectedDate?.value)
                            .toISOString()
                            .split('T')[0]
                        )
                      }
                      className="w-full !h-8"
                      key={data.field}
                    />
                  ) : fieldType === 'textarea' ? (
                    <div className="col-span-2">
                      <EditableTextarea
                        name={data.field as keyof AddRowType}
                        disabled={false}
                        label={data?.headerText}
                        value={newRow[data.field as keyof AddRowType]}
                        onChange={(e: any) =>
                          handleInputChange(data.field, e.target.value)
                        }
                        className="w-full"
                        key={data.field}
                        rows={10}
                      />
                    </div>
                  ) : fieldType === 'checkbox' ? null : (
                    <EditabeInput
                      name={data.field as keyof AddRowType}
                      disabled={false}
                      label={data?.headerText}
                      value={newRow[data.field as keyof AddRowType]}
                      onChange={(e: any) =>
                        handleInputChange(data.field, e.target.value)
                      }
                      className="w-full"
                      key={data.field}
                    />
                  )}
                </React.Fragment>
              );
            })}
        </div>
        <div className="mt-4 flex space-x-2">
          <button
            onClick={handleAddClick}
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-1.5 w-28 rounded"
          >
            Save
          </button>
          <button
            onClick={handleModalClose}
            className="border border-blue-200 hover:bg-blue-100  py-1.5 px-4 rounded"
          >
            Cancel
          </button>
        </div>
      </Box>
    </Modal>
  );
};

export default AddRowModal;
