export type HeaderConfig = {
  field: string;
  headerText: string;
  show?: boolean;
  headerTemplate?: (row: any) => JSX.Element;
  isDisabled?: boolean;
  width?: string;
  field_type?: 'input' | 'select' | 'date' | 'textarea' | 'checkbox';
};

export interface TableProps {
  head: HeaderConfig[];
  data: any[];
}

export interface DataRow {
  id: string;
  name: string;
  address: string;
  pin: number;
  age: number;
  email: string;
  phone: string;
  status: string;
  role: string;
  registered: string; // You might want to use Date type if you process dates
}

// Define the types for the data structure

export interface CreatedBy {
  created_by: string;
  emp_no: number;
}

export interface Transaction {
  brsMasterId: string;
  bankTransactionDate: string;
  particulars: string;
  chequeNo: string;
  dbAmt: string;
  crAmt: string;
  balance: string;
  reconciliationFlag: boolean;
  deleteFlag: boolean;
  deletedDate: string | null;
  createdAt: string;
  updatedAt: string | null;
  id: string;
  createdBy: CreatedBy | null;
  updatedBy: CreatedBy | null;
}

export interface DataItem {
  accountId: string;
  fromDate: string;
  toDate: string;
  docId: string[];
  createdBy: CreatedBy;
  updatedBy: CreatedBy | null;
  deleteFlag: boolean;
  deletedDate: string | null;
  createdAt: string;
  updatedAt: string | null;
  id: string;
  transactions: Transaction[];
}
export interface TransformedTransaction {
  bankTransactionDate: string;
  particulars: string;
  chequeNo: string;
  dbAmt: string;
  crAmt: string;
  balance: string;
  id: string;
}

export interface AddRowType {
  bankTransactionDate: string;
  particulars: string;
  chequeNo: string;
  dbAmt: string;
  crAmt: string;
  balance: string;
}

export type sortConfigType = {
  key: keyof TransformedTransaction;
  direction: 'asc' | 'desc' | 'default';
};

export type EditableTableType = {
  data: TransformedTransaction[];
  setData: React.Dispatch<React.SetStateAction<TransformedTransaction[]>>;
  editableTableHead: HeaderConfig[];
  editable?: boolean;
  viewonly?: boolean;
  loading?: boolean;
  allowExcelExport?: boolean;
  allowPrint?: boolean;
  
};

export type ConvertedDataForUpdate = {
  id: string;
  accountId: string;
  fromDate: string;
  toDate: string;
  docId: string;
  data: AddRowType[];
};
